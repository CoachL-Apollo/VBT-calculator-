(function(){
  const get = id => document.getElementById(id);
  const ids = [0,1,2,3];
  const inputs = {
    load: ids.map(i => get('load'+i)),
    vel: ids.map(i => get('vel'+i)),
    targetV: get('targetV'),
    targetSlider: get('targetSlider'),
    resetBtn: get('resetBtn'),
  };
  const out = {
    slope: get('slope'),
    intercept: get('intercept'),
    r2: get('r2'),
    pred: get('pred'),
    pred25: get('pred25'),
    pred5: get('pred5'),
    tvLabel: get('tvLabel'),
    chart: get('chart')
  };

  function isNum(n){ return typeof n === 'number' && !Number.isNaN(n) && Number.isFinite(n); }
  function roundTo(v, step){ return Math.round(v/step)*step; }

  function readRows(){
    const rows = [];
    for(let i=0;i<4;i++){
      const L = Number(inputs.load[i].value);
      const V = Number(inputs.vel[i].value);
      if(isNum(L) && isNum(V)) rows.push({load:L, vel:V});
    }
    return rows;
  }

  function linearFit(xs, ys){
    const n = xs.length;
    if(n < 2) return null;
    const mean = arr => arr.reduce((s,v)=>s+v,0)/n;
    const xbar = mean(xs), ybar = mean(ys);
    let ssxx=0, ssxy=0, ssyy=0;
    for(let i=0;i<n;i++){
      const dx = xs[i]-xbar, dy = ys[i]-ybar;
      ssxx += dx*dx; ssxy += dx*dy; ssyy += dy*dy;
    }
    if(ssxx === 0) return null;
    const a = ssxy/ssxx, b = ybar - a*xbar;
    let ssRes = 0;
    for(let i=0;i<n;i++){
      const yhat = a*xs[i] + b;
      ssRes += (ys[i]-yhat)**2;
    }
    const r2 = 1 - ssRes/ssyy;
    return {a,b,r2};
  }

  function update(){
    const rows = readRows();
    const xs = rows.map(r=>r.vel);
    const ys = rows.map(r=>r.load);
    const fit = linearFit(xs, ys);

    if(fit){
      out.slope.textContent = fit.a.toFixed(2);
      out.intercept.textContent = fit.b.toFixed(2);
      out.r2.textContent = isNum(fit.r2) ? fit.r2.toFixed(3) : '–';
    } else {
      out.slope.textContent = '–';
      out.intercept.textContent = '–';
      out.r2.textContent = '–';
    }

    const tv = Number(inputs.targetV.value);
    inputs.targetSlider.value = isNum(tv) ? tv : inputs.targetSlider.value;
    out.tvLabel.textContent = isNum(tv) ? tv.toFixed(2) : '–';

    if(fit && isNum(tv)){
      const pred = fit.a*tv + fit.b;
      out.pred.textContent = pred.toFixed(1) + ' kg';
      out.pred25.textContent = roundTo(pred, 2.5).toFixed(1);
      out.pred5.textContent = roundTo(pred, 5).toFixed(0);
    } else {
      out.pred.textContent = '– kg';
      out.pred25.textContent = '–';
      out.pred5.textContent = '–';
    }

    drawChart(rows, fit, tv);
  }

  function drawChart(rows, fit, tv){
    const svg = out.chart;
    while(svg.firstChild) svg.removeChild(svg.firstChild);

    const W=700, H=420;
    const margin = {l:70, r:20, t:20, b:50};
    const iw = W - margin.l - margin.r;
    const ih = H - margin.t - margin.b;

    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);

    function append(tag, attrs={}, parent=svg){
      const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
      for(const k in attrs) el.setAttribute(k, attrs[k]);
      parent.appendChild(el);
      return el;
    }

    const g = append('g', {transform:`translate(${margin.l},${margin.t})`});

    const vx = rows.map(r=>r.vel);
    const vy = rows.map(r=>r.load);
    if(vx.length===0 || vy.length===0){ return; }

    const minX = Math.max(0, Math.min(...vx) - 0.1);
    const maxX = Math.max(...vx) + 0.1;
    const minY = 0;
    const maxY = Math.max(...vy) * 1.15;

    const xScale = x => margin.l + ( (x - minX) / (maxX - minX) ) * iw;
    const yScale = y => margin.t + ih - ( (y - minY) / (maxY - minY) ) * ih;

    // Grid + axes
    append('rect', {x:margin.l, y:margin.t, width:iw, height:ih, fill:'#fff', stroke:'#e6e6ef'});
    // Y ticks
    const yTicks = 5;
    for(let i=0;i<=yTicks;i++){
      const yv = minY + (i/yTicks)*(maxY-minY);
      const y = yScale(yv);
      append('line', {x1:margin.l, y1:y, x2:margin.l+iw, y2:y, stroke:'#f0f0f5'});
      append('text', {x:margin.l-8, y:y+4, 'text-anchor':'end', 'font-size':'11'}, svg).textContent = yv.toFixed(0);
    }
    // X ticks
    const xTicks = 6;
    for(let i=0;i<=xTicks;i++){
      const xv = minX + (i/xTicks)*(maxX-minX);
      const x = xScale(xv);
      append('line', {x1:x, y1:margin.t, x2:x, y2:margin.t+ih, stroke:'#f0f0f5'});
      append('text', {x:x, y:margin.t+ih+18, 'text-anchor':'middle', 'font-size':'11'}, svg).textContent = xv.toFixed(2);
    }
    // Axis labels
    append('text', {x:margin.l+iw/2, y:H-8, 'text-anchor':'middle', 'font-size':'12', fill:'#333'}, svg).textContent = 'Mean Velocity (m/s)';
    append('text', {x:16, y:margin.t+ih/2, 'text-anchor':'middle', 'font-size':'12', fill:'#333', transform:`rotate(-90,16,${margin.t+ih/2})`}, svg).textContent = 'Load (kg)';

    // Points
    rows.forEach(r=>{
      const cx = xScale(r.vel);
      const cy = yScale(r.load);
      append('circle', {cx, cy, r:4, fill:'#4a6cff'});
    });

    // Regression line
    if(fit){
      const x0 = minX, x1 = maxX;
      const y0 = fit.a*x0 + fit.b;
      const y1 = fit.a*x1 + fit.b;
      append('line', {x1:xScale(x0), y1:yScale(y0), x2:xScale(x1), y2:yScale(y1), stroke:'#111', 'stroke-width':2});
    }

    // Target vertical line
    if(isNum(tv)){
      const x = xScale(tv);
      append('line', {x1:x, y1:margin.t, x2:x, y2:margin.t+ih, stroke:'#888', 'stroke-dasharray':'6 4'});
      append('text', {x:x+6, y:margin.t+14, 'font-size':'11', fill:'#555'}, svg).textContent = `v=${tv.toFixed(2)} m/s`;
    }
  }

  ids.forEach(i=>{
    inputs.load[i].addEventListener('input', update);
    inputs.vel[i].addEventListener('input', update);
  });
  inputs.targetV.addEventListener('input', ()=>{
    inputs.targetSlider.value = inputs.targetV.value;
    update();
  });
  inputs.targetSlider.addEventListener('input', ()=>{
    inputs.targetV.value = inputs.targetSlider.value;
    update();
  });

  inputs.resetBtn.addEventListener('click', ()=>{
    const L = [40,60,80,100];
    const V = [1.10,0.90,0.70,0.50];
    for(let i=0;i<4;i++){ inputs.load[i].value=L[i]; inputs.vel[i].value=V[i]; }
    inputs.targetV.value = '0.60';
    inputs.targetSlider.value = '0.60';
    update();
  });

  // initial
  update();
})();